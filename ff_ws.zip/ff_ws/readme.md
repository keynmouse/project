# We have built a conveyor system that measures relative positions using a global camera,
# performs object detection with a robot’s camera and YOLOv8,
# and is managed through a control room GUI.

# The planning of the robot's movement path is currently in progress.






