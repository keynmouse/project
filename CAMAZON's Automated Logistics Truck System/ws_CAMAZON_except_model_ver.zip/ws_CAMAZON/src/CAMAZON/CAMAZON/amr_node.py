# test/test_camera_node.py
import cv2
import math
import rclpy
import numpy as np

from rclpy.node import Node
from std_msgs.msg import String ,Int32
from geometry_msgs.msg import Twist
from rclpy.action import ActionClient
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose

from CAMAZON.yolo_detector import YOLODetector

# define names of each possible ArUco tag OpenCV supports
ARUCO_DICT = {
	"DICT_4X4_50": cv2.aruco.DICT_4X4_50,
	"DICT_4X4_100": cv2.aruco.DICT_4X4_100,
	"DICT_4X4_250": cv2.aruco.DICT_4X4_250,
	"DICT_4X4_1000": cv2.aruco.DICT_4X4_1000,
	"DICT_5X5_50": cv2.aruco.DICT_5X5_50,
	"DICT_5X5_100": cv2.aruco.DICT_5X5_100,
	"DICT_5X5_250": cv2.aruco.DICT_5X5_250,
	"DICT_5X5_1000": cv2.aruco.DICT_5X5_1000,
	"DICT_6X6_50": cv2.aruco.DICT_6X6_50,
	"DICT_6X6_100": cv2.aruco.DICT_6X6_100,
	"DICT_6X6_250": cv2.aruco.DICT_6X6_250,
	"DICT_6X6_1000": cv2.aruco.DICT_6X6_1000,
	"DICT_7X7_50": cv2.aruco.DICT_7X7_50,
	"DICT_7X7_100": cv2.aruco.DICT_7X7_100,
	"DICT_7X7_250": cv2.aruco.DICT_7X7_250,
	"DICT_7X7_1000": cv2.aruco.DICT_7X7_1000,
	"DICT_ARUCO_ORIGINAL": cv2.aruco.DICT_ARUCO_ORIGINAL,
	"DICT_APRILTAG_16h5": cv2.aruco.DICT_APRILTAG_16h5,
	"DICT_APRILTAG_25h9": cv2.aruco.DICT_APRILTAG_25h9,
	"DICT_APRILTAG_36h10": cv2.aruco.DICT_APRILTAG_36h10,
	"DICT_APRILTAG_36h11": cv2.aruco.DICT_APRILTAG_36h11
}

Type = 'DICT_4X4_50'
#640 480
'''
K = np.array([
        [931.29947826,   0.0,         353.86698242],
        [0.0,         933.53971886 ,256.14156235],
        [0.00000000e+00, 0.00000000e+00, 1.00000000e+00]], dtype=np.float32)

D = np.array([ 0.01682999,  0.02914762, -0.00508395, -0.00672223, -2.49680361], dtype=np.float32)

#1280 720
K = np.array([
        [1.48773031e+03, 0.00000000e+00, 7.37781509e+02],
        [0.00000000e+00, 1.48450811e+03, 4.03336931e+02],
        [0.00000000e+00, 0.00000000e+00, 1.00000000e+00]], dtype=np.float32)

D = np.array([ 4.59250975e-02,  1.08105581e+00,  4.14937536e-03,  4.73976534e-03,  -6.69692072e+00], dtype=np.float32)
'''

#1280 720 2
K = np.array([
        [1.46103676e+03, 0.00000000e+00, 6.82966235e+02],
        [0.00000000e+00, 1.44350554e+03, 4.38658984e+02],
        [0.00000000e+00, 0.00000000e+00, 1.00000000e+00]], dtype=np.float32)

D = np.array([ 0.05748813,  0.53140533,  0.00606831,  0.00485003, -1.99675499], dtype=np.float32)

unit_x = np.array([[1.0], [0.0], [0.0]])
unit_y = np.array([[0.0], [1.0], [0.0]])
unit_z = np.array([[0.0], [0.0], [1.0]])

# ArUco 마커 설정
aruco_dict = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)  # 사용할 ArUco 마커의 종류
parameters = cv2.aruco.DetectorParameters_create()  # 최신 버전에서 DetectorParameters()로 수정

class Amr_Node(Node):
    def __init__(self):
        super().__init__('amr_node')

        self.car_cmdvel=self.create_publisher(Twist, '/cmd_vel',10)
        self.cmd=Twist()
        
        self.nav2_cli=ActionClient(self, NavigateToPose, '/navigate_to_pose')
        
        self.new_id=self.create_subscription(Int32,'/id',self.is_new,10)
        self.aruco_id=None
        # Initialize camera
        # ls -l /dev/video* 의 연속된 2개의 숫자중 앞선 숫자가 카메라 인덱스
        self.declare_parameter('cam_index',1)
        self.cam_index = self.get_parameter('cam_index').value
        self.get_logger().info(f'Cam Index: {self.cam_index}')
        
        self.cap = cv2.VideoCapture(self.cam_index, cv2.CAP_V4L2)
        
        if not self.cap.isOpened():
            self.get_logger().error('카메라를 열 수 없습니다!')
            return

        # Set camera properties
        self.cam_width = 1280
        self.cam_height = 720
        # 카메라 해상도 이슈로 추가
        self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.cam_width)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.cam_height)
        
        # Timer
        #self.create_timer(0.033, self.camera_image) # 30Hz
        
        self.get_logger().info('amr node started')

    def is_new(self,msg):
        self.aruco_id=msg.data
        self.send_goal()
    
    def detect(self):
        yolo_detector = YOLODetector(
            model_path='./models/best.pt',  # Use YOLOv8 nano model
            conf_threshold=0.8
        )
        TT=True
        while TT:
            ret, frame = self.cap.read()
            if not ret:
                print('not ret')
                break
                
            # Run detection
            detections, annotated_frame = yolo_detector.detect_image(frame)
            
            # Print detections
            for det in detections:
                print(f"Detected {det['class_name']} with confidence {det['confidence']:.2f}")
                x_start = det['bbox'][0]
                x_end = det['bbox'][3]
                y_start = 0
                y_end = 480
                cropped_image=frame[y_start:y_end, x_start:x_end]
                if (x_end-x_start)>0:
                    cv2.imwrite('YOLOv8_Detection_crop.jpg', cropped_image)
                    corners,ids, rejectedImgPoints = cv2.aruco.detectMarkers(cropped_image, aruco_dict, parameters=parameters)
                    if ids == self.aruco_id:
                        print('id')
                        TT=False
                    else:
                        print('id2')
            # Show results
            print('id3')
            cv2.imwrite('YOLOv8_Detection.jpg', annotated_frame)
            cv2.waitKey(1)
        
        cv2.destroyAllWindows()
        print('id4')
        self.create_timer(0.033, self.camera_image)
        
    def camera_image(self):
        ret, frame = self.cap.read()

        if not ret:
            print("프레임을 읽을 수 없습니다.")

        # 이미지 왜곡 보정
        undistorted_image = cv2.undistort(frame.copy(), K, D)
        
        # ArUco 마커 감지
        corners, ids, rejectedImgPoints = cv2.aruco.detectMarkers(undistorted_image, aruco_dict, parameters=parameters)
        count=0

        id_index=None
        
        # 마커가 감지되면
        if len(corners) > 0:
            for id in ids:
                if id == self.aruco_id: #추후에 id를 받아와서 실행 예정 현재 임의값
                    id_index=count
                count+=1
            # 각 마커에 대해 포즈 추정
            if id_index!=None:
                marker_length = 50
                rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners[id_index], marker_length, K, D)
                print(rvecs)
                R,_=cv2.Rodrigues(rvecs)
                pitch = np.arctan2(-R[2, 0], np.sqrt(R[2, 1]**2 + R[2, 2]**2))  # Y축 회전 (pitch)
                pitch_deg = np.degrees(pitch)
                
                self.cmd_pub(tvecs[0][0][0],tvecs[0][0][2],pitch_deg)

        else:
            self.cmd_pause()
            print('pause')

    def cmd_pause(self):
        self.cmd.linear.x=0.0
        self.cmd.angular.z=0.0
        self.car_cmdvel.publish(self.cmd)
        
    def cmd_pub(self, x,z,yaw):
        dis=math.sqrt(z*z+x*x)
        print(f"z : {z}, x : {x}, yaw : {yaw}")
        
        if x>40.0 and dis>400 and dis<900:
            self.cmd.linear.x=0.1
            self.cmd.angular.z=-0.2
            self.car_cmdvel.publish(self.cmd)
            print(111)
        elif x<-40.0 and dis>400 and dis<900:
            self.cmd.linear.x=0.1
            self.cmd.angular.z=0.2
            self.car_cmdvel.publish(self.cmd)
            print(222)
        else:
            if dis>400 and dis<900:
                print(2)
                self.cmd.linear.x=0.14
                self.cmd.angular.z=(-yaw/80)*(dis/600)
                print(self.cmd)
                self.car_cmdvel.publish(self.cmd)
            elif dis<=400 and dis>300:
                print(3)
                self.cmd.linear.x=0.0
                self.cmd.angular.z=0.0
                self.car_cmdvel.publish(self.cmd)
            elif dis<=300:
                print(4)
                self.cmd.linear.x=-0.05
                self.cmd.angular.z=-yaw/80*(100/dis)
                self.car_cmdvel.publish(self.cmd)
            else:
                self.cmd.linear.x=0.0
                self.cmd.angular.z=0.0
                self.car_cmdvel.publish(self.cmd)
                
    def send_goal(self):
        print(self.aruco_id)
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal_pose.pose.position.x = 1.0  # Target x position 실제 맵 위치 추정 필요
        goal_pose.pose.position.y = 1.0  # Target y position 실제 맵 위치 추정 필요
        goal_pose.pose.orientation.w = 1.0  # No rotation (facing forward)
        # Wait for action server to be available
        self.nav2_cli.wait_for_server()

        # Create a goal message
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose

        # Send the goal and attach a callback for result
        self._send_goal_future = self.nav2_cli.send_goal_async(goal_msg)
        self._send_goal_future.add_done_callback(self.goal_response_callback)

    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected :(')
            return
        
        self.get_logger().info('Goal accepted :)')

        # Attach a callback for the result
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)
        
        return self.get_logger().info('Goal was accepted by the action server')

    def get_result_callback(self, future):
        action_status=future.result().status
        if action_status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info('Goal succeeded!')
            #이 부분에 디텍션 함수 추가 필요 이후 디텍션 함수내에서 aruco 함수 실행하는 방식으로
            self.detect()
        else:
            print('Goal failed')
        

def main(args=None):
    rclpy.init(args=args)
    node = Amr_Node()
    
    try:
        rclpy.spin(node)
        
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()