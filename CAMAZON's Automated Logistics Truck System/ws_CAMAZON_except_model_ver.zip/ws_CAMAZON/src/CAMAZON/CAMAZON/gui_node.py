import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from rclpy.callback_groups import ReentrantCallbackGroup
from cv_bridge import CvBridge
import sys
import cv2
import numpy as np
from datetime import datetime
import json
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import smtplib
from PyQt5.QtWidgets import *
from PyQt5.QtWidgets import QSizePolicy, QTableWidget, QTableWidgetItem, QSpinBox, QHeaderView
from PyQt5.QtCore import Qt, QTimer, QThreadPool, QRunnable
from PyQt5.QtGui import QImage, QPixmap
import time

from CAMAZON.login import LoginDialog
from CAMAZON.yolo_detector import YOLODetector
from CAMAZON.yolo_target import YOLOTracker
from CAMAZON.DB import Database

# from login import LoginDialog
# from yolo_target import YOLODTarget
# from yolo_detector import YOLODetector


class RobotControlUINode(Node):
    def __init__(self):
        super().__init__('GUI_node')

        # 기본 설정들은 유지
        self.bridge = CvBridge()
        self.is_car = False
        self.IDs = []

        # 데이터베이스 설정
        self.DB = Database()

        self._action_client = ActionClient(
            self,
            NavigateToPose,
            'navigate_to_pose',
            callback_group=ReentrantCallbackGroup())
        
        # 액션 서버가 시작될 때까지 대기
        self._action_client.wait_for_server()

        # YOLO 초기화
        self.yolo_detector = YOLODetector(
            model_path='./models/best.pt',  # Use YOLOv8 nano model
            conf_threshold=0.8
        )


        # YOLO 초기화
        self.yolo_target = YOLOTracker(
            model_path='./models/best.pt',  # Use YOLOv8 nano model
            conf_threshold=0.8
        )

        # 파라미터 선언 (기본값: 0)
        self.declare_parameter('cam_index', 0)
        self.cam_index = self.get_parameter('cam_index').value
        self.get_logger().info(f'Cam Index: {self.cam_index}')

        # Initialize camera
        # ls -l /dev/video* 의 연속된 2개의 숫자중 앞선 숫자가 카메라 인덱스
        self.cap = cv2.VideoCapture(self.cam_index, cv2.CAP_V4L2)
        if not self.cap.isOpened():
            self.get_logger().error('카메라를 열 수 없습니다!')
            return
        


        # Set camera properties

        # self.cam_width = 640
        # self.cam_height = 480
        # # 카메라 해상도 이슈로 추가
        # # self.cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc('M', 'J', 'P', 'G'))

        # self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.cam_width)
        # self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.cam_height)

        # UI 초기화
        self.app = QApplication(sys.argv)
        self.init_ui()

        self.create_timer(0.033, self.publish_camera_images) # 30Hz
        self.get_logger().info('Gui node started')

    def init_ui(self):
        """Initialize the user interface"""
        self.window = QMainWindow()
        self.window.setWindowTitle('Robot Control System')
        self.window.setGeometry(100, 100, 1200, 800)
        self.window.setStyleSheet("""
            QMainWindow {
                background-color: #f0f0f0;
            }
            QGroupBox {
                border: 2px solid #cccccc;
                border-radius: 6px;
                margin-top: 1ex;
                font-weight: bold;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                padding: 0 5px;
            }
            QTextEdit {
                border: 1px solid #cccccc;
                border-radius: 4px;
                padding: 5px;
                background-color: white;
            }
        """)
    
        # Create central widget and layout
        central_widget = QWidget()
        self.window.setCentralWidget(central_widget)
        main_layout = QHBoxLayout(central_widget)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(20, 20, 20, 20)
    
        # Left panel for camera feed
        left_panel = QVBoxLayout()
        left_panel.setSpacing(15)
    
        # Camera feed in group box
        camera_group = QGroupBox("Camera Feed")
        camera_layout = QVBoxLayout()
        
        # Camera label setup
        self.camera_label = QLabel()
        self.camera_label.setMinimumSize(800, 600)
        self.camera_label.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.camera_label.setStyleSheet("""
            QLabel {
                background-color: #1e1e1e;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        camera_layout.addWidget(self.camera_label)
        camera_group.setLayout(camera_layout)
        left_panel.addWidget(camera_group)
    
        # Right panel for log
        right_panel = QVBoxLayout()
        right_panel.setSpacing(15)
    
        # Log group
        log_group = QGroupBox("System Logs")
        log_layout = QVBoxLayout()
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMinimumWidth(300)
        self.log_text.setStyleSheet("""
            QTextEdit {
                font-family: 'Consolas', monospace;
                font-size: 12px;
                line-height: 1.5;
            }
        """)
        log_layout.addWidget(self.log_text)
        
        log_group.setLayout(log_layout)
        right_panel.addWidget(log_group)
    
        # Add panels to main layout
        main_layout.addLayout(left_panel, stretch=2)
        main_layout.addLayout(right_panel, stretch=1)
    
        self.window.show()


    def publish_camera_images(self):
        # Create Camera images topic
        global_image = self.get_camera_image("Global Camera")

        # BGR에서 RGB로 변환
        global_image = cv2.cvtColor(global_image, cv2.COLOR_BGR2RGB)
        
        # Display
        self.update_camera_display(global_image)
        

    def get_camera_image(self, text = "Global Cam"):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn('카메라에서 프레임을 읽을 수 없습니다!')
            return np.zeros((self.cam_height, self.cam_width, 3), dtype=np.uint8)
        
    

        if self.is_car:
            annotation, annotated_frame = self.yolo_target.track_image(frame)
            # print("tracking")
            if not annotation:
                self.is_car = False
            else:
                if self.judgement_new_ID(annotation):
                    # TODO
                    pose = NavigateToPose.Goal()
                    self.send_goal(pose)

        else:
            annotation, annotated_frame = self.yolo_detector.detect_image(frame)
            print("detection")
            if annotation:
                self.is_car = True


        # Add text and timestamp
        cv2.putText(annotated_frame, text, (50, 50), 
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        cv2.putText(annotated_frame, time.strftime("%H:%M:%S"), (50, 100),
                   cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        

        return annotated_frame
    
    def judgement_new_ID(self, annotations):
        result = []
        for annotation in annotations:
            id = annotation['track_id']
            if not id in self.IDs:
                result.append(id)
                self.IDs.append(id)

        self.IDs = list(set(self.IDs))

        return result


    
    def update_camera_display(self, cv_image):
        """카메라 디스플레이 업데이트"""
        try:
            height, width, channel = cv_image.shape
            bytes_per_line = 3 * width
            q_img = QImage(cv_image.data, width, height, bytes_per_line, QImage.Format_RGB888)

            # 레이블 크기 가져오기
            label_size = self.camera_label.size()

            # 이미지를 레이블 크기에 맞게 스케일링하되 비율 유지
            pixmap = QPixmap.fromImage(q_img)
            scaled_pixmap = pixmap.scaled(
                label_size,
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation
            )

            self.camera_label.setPixmap(scaled_pixmap)
            self.camera_label.setAlignment(Qt.AlignCenter)
        except Exception as e:
            self.get_logger().error(f'Failed to update camera display: {str(e)}')
            self.log_text.append(f'Display Error: {str(e)}')


    def send_goal(self, pose):
        print("send_goal_send_goal_send_goal_send_goal_send_goal_send_goal_send_goal_send_goal_send_goal_")
        return
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose
        
        self.get_logger().info('목표 위치로 이동을 시작합니다...')
        
        # 액션 목표를 보내고 피드백과 결과를 받을 콜백 함수 설정
        self._send_goal_future = self._action_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback)
        
        self._send_goal_future.add_done_callback(self.goal_response_callback)
    
    def goal_response_callback(self, future):
        goal_handle = future.result()
        
        if not goal_handle.accepted:
            self.get_logger().error('목표가 거부되었습니다.')
            return
            
        self.get_logger().info('목표가 수락되었습니다.')
        
        # 결과를 받을 콜백 설정
        self._get_result_future = goal_handle.get_result_async()
        self._get_result_future.add_done_callback(self.get_result_callback)
    
    def get_result_callback(self, future):
        result = future.result().result
        status = future.result().status
        if status == 4:
            self.get_logger().info('목표에 도달했습니다!')
        else:
            self.get_logger().error(f'탐색 실패. 상태: {status}')
    
    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        # 현재 로봇의 위치를 출력
        self.get_logger().info(f'현재 위치 - X: {feedback.current_pose.pose.position.x:.2f}, '
                              f'Y: {feedback.current_pose.pose.position.y:.2f}')



# 로그인 처리
def login_process():
    app = QApplication.instance()
    if app is None:
        app = QApplication(sys.argv)
    
    login = LoginDialog()
    if login.exec_() != QDialog.Accepted:
        print("[INFO] Login Failed!")
        sys.exit()
    else:
        print("[INFO] Login Success!")

def main(args=None):
    login_process()
    rclpy.init(args=args)
    node = RobotControlUINode()
    
    while rclpy.ok():
        rclpy.spin_once(node, timeout_sec=0)
        node.app.processEvents()
    
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()