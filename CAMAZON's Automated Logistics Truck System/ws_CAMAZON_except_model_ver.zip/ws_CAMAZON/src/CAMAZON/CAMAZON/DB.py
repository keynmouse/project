import sqlite3
import uuid
from datetime import datetime

class Database:
    def __init__(self, db_name="database.db"):
        """
        데이터베이스 초기화
        Args:
            db_name (str): 데이터베이스 파일 이름
        """
        self.db_name = db_name
        self.conn = None
        self.cursor = None
        
    def connect(self):
        """데이터베이스 연결"""
        self.conn = sqlite3.connect(self.db_name)
        self.cursor = self.conn.cursor()
        
    def create_table(self):
        """테이블 생성"""
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS records (
                uuid TEXT PRIMARY KEY,         -- UUID를 TEXT로 저장 (SQLite는 UUID 타입이 없음)
                timestamp DATETIME NOT NULL,   -- 타임스탬프를 DATETIME으로 저장
                recorder TEXT NOT NULL,        -- 기록자 정보를 TEXT로 저장
                state TEXT NOT NULL           -- 상태 정보를 TEXT로 저장
            )
        ''')
        self.conn.commit()
        
    def close(self):
        """데이터베이스 연결 종료"""
        if self.conn:
            self.conn.close()
            
    def insert_record(self, recorder, state):
        """
        새로운 레코드 추가
        Args:
            recorder (str): 기록자 정보
            state (str): 상태 정보
        Returns:
            str: 생성된 UUID
        """
        new_uuid = str(uuid.uuid4())
        current_time = datetime.now()
        
        self.cursor.execute('''
            INSERT INTO records (uuid, timestamp, recorder, state)
            VALUES (?, ?, ?, ?)
        ''', (new_uuid, current_time, recorder, state))
        
        self.conn.commit()
        return new_uuid
        
    def get_all_records(self):
        """
        모든 레코드 조회
        Returns:
            list: 모든 레코드의 리스트
        """
        self.cursor.execute('SELECT * FROM records')
        records = self.cursor.fetchall()
        
        # 결과를 딕셔너리 리스트로 변환
        columns = ['uuid', 'timestamp', 'recorder', 'state']
        result = []
        for record in records:
            result.append(dict(zip(columns, record)))
            
        return result