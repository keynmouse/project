# from ultralytics import YOLO
# import cv2
# import numpy as np
# from typing import Tuple, List, Dict



# class YOLOTracker:
#     def __init__(self, model_path: str, conf_threshold: float = 0.3, iou_threshold: float = 0.5):
#         """
#         Initialize YOLOv8 detector with tracking capabilities
#         Args:
#             model_path: Path to the YOLOv8 model file (.pt)
#             conf_threshold: Confidence threshold for detections
#             iou_threshold: IOU threshold for tracking
#         """
#         self.model = YOLO(model_path)
#         self.conf_threshold = conf_threshold
#         self.iou_threshold = iou_threshold


#     def track_image(self, image: np.ndarray) -> Tuple[List[Dict], np.ndarray]:
#         """
#         Detect and track objects in an image
#         Args:
#             image: Input image in BGR format (OpenCV)
#         Returns:
#             Tuple containing tracking results and annotated image
#         """

#         # Run inference with tracking
#         results = self.model.track(
#             source=image,
#             conf=self.conf_threshold,
#             iou=self.iou_threshold,
#             persist=True,  # Enable track persistence between frames
#         )[0]
        
#         # Process results
#         tracking_results = []
        
#         if hasattr(results.boxes, 'id') and results.boxes.id is not None:
#             for i, box in enumerate(results.boxes):
#                 if box.conf[0] >= self.conf_threshold:
#                     track_id = int(box.id[0])
#                     xyxy = box.xyxy[0].cpu().numpy()
#                     class_id = int(box.cls[0])
#                     conf = float(box.conf[0])
                    
#                     tracking_results.append({
#                         'track_id': track_id,
#                         'bbox': [int(x) for x in xyxy],
#                         'confidence': conf,
#                         'class_id': class_id,
#                         'class_name': results.names[class_id]
#                     })

#         # Draw tracking results
#         annotated_image = image.copy()
#         for track in tracking_results:
#             bbox = track['bbox']
#             track_id = track['track_id']
#             label = f"{track['class_name']} #{track_id} {track['confidence']:.2f}"
            
#             # Draw rectangle
#             cv2.rectangle(annotated_image, 
#                         (bbox[0], bbox[1]), 
#                         (bbox[2], bbox[3]), 
#                         (0, 255, 0), 2)
            
#             # Draw label with track ID
#             cv2.putText(annotated_image, label, 
#                        (bbox[0], bbox[1] - 10),
#                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, 
#                        (0, 255, 0), 2)

#         return tracking_results, annotated_image

# def main():
#     # Initialize tracker
#     tracker = YOLOTracker(
#         model_path='yolov8n.pt',  # Use YOLOv8 nano model
#         conf_threshold=0.3,
#         iou_threshold=0.5
#     )
    
#     # Open video capture (0 for webcam)
#     cap = cv2.VideoCapture(0)
    
#     while True:
#         ret, frame = cap.read()
#         if not ret:
#             break
            
#         # Run tracking
#         tracking_results, annotated_frame = tracker.track_image(frame)
        
#         # Print tracking results
#         for track in tracking_results:
#             print(f"Tracking ID {track['track_id']}: {track['class_name']} "
#                   f"at position ({track['bbox'][0]}, {track['bbox'][1]})")
        
#         # Show results
#         cv2.imshow('YOLOv8 Tracking', annotated_frame)
        
#         # Break loop on 'q' press
#         if cv2.waitKey(1) & 0xFF == ord('q'):
#             break
    
#     cap.release()
#     cv2.destroyAllWindows()

# if __name__ == "__main__":
#     main()



from ultralytics import YOLO
import cv2
import numpy as np
from typing import Tuple, List, Dict
from collections import deque
import time

class YOLOTracker:
    def __init__(self, model_path: str, conf_threshold: float = 0.3, iou_threshold: float = 0.5):
        """
        Initialize YOLOv8 detector with enhanced tracking capabilities
        """
        self.model = YOLO(model_path)
        self.conf_threshold = conf_threshold
        self.iou_threshold = iou_threshold
        
        # 트래킹 이력 저장을 위한 딕셔너리
        self.track_history = {}
        # 각 트랙의 마지막 감지 시간 저장
        self.last_seen = {}
        # 트랙 유지 시간 (초)
        self.track_timeout = 5.0
        
    def update_track_history(self, track_id: int, bbox: List[int], current_time: float):
        """
        Update tracking history for visualization and trajectory analysis
        """
        if track_id not in self.track_history:
            self.track_history[track_id] = deque(maxlen=150)  # 최대 30개 포인트 저장
            
        center_x = (bbox[0] + bbox[2]) // 2
        center_y = (bbox[1] + bbox[3]) // 2
        self.track_history[track_id].append((center_x, center_y))
        self.last_seen[track_id] = current_time

    def clean_old_tracks(self, current_time: float):
        """
        Remove old tracks that haven't been seen recently
        """
        ids_to_remove = []
        for track_id, last_time in self.last_seen.items():
            if current_time - last_time > self.track_timeout:
                ids_to_remove.append(track_id)
                
        for track_id in ids_to_remove:
            del self.track_history[track_id]
            del self.last_seen[track_id]

    def track_image(self, image: np.ndarray) -> Tuple[List[Dict], np.ndarray]:
        """
        Enhanced object tracking with trajectory visualization
        """
        current_time = time.time()
        
        # 트래킹 실행
        results = self.model.track(
            source=image,
            conf=self.conf_threshold,
            iou=self.iou_threshold,
            persist=True,
            verbose=False
        )[0]
        
        tracking_results = []
        
        if hasattr(results.boxes, 'id') and results.boxes.id is not None:
            for i, box in enumerate(results.boxes):
                if box.conf[0] >= self.conf_threshold:
                    track_id = int(box.id[0])
                    xyxy = box.xyxy[0].cpu().numpy()
                    class_id = int(box.cls[0])
                    conf = float(box.conf[0])
                    
                    # 트래킹 이력 업데이트
                    self.update_track_history(track_id, [int(x) for x in xyxy], current_time)
                    
                    tracking_results.append({
                        'track_id': track_id,
                        'bbox': [int(x) for x in xyxy],
                        'confidence': conf,
                        'class_id': class_id,
                        'class_name': results.names[class_id]
                    })
        
        # 오래된 트랙 제거
        self.clean_old_tracks(current_time)
        
        # 결과 시각화
        annotated_image = image.copy()
        
        # 트래킹 이력 그리기
        for track_id, history in self.track_history.items():
            points = np.array(list(history), dtype=np.int32)
            if len(points) > 1:
                cv2.polylines(annotated_image, [points], 
                            isClosed=False, 
                            color=(0, 255, 255), 
                            thickness=2)
                
        
        # 현재 감지된 객체 그리기
        for track in tracking_results:
            bbox = track['bbox']
            track_id = track['track_id']
            label = f"{track['class_name']} #{track_id} {track['confidence']:.2f}"
            
            # 박스 그리기
            cv2.rectangle(annotated_image, 
                        (bbox[0], bbox[1]), 
                        (bbox[2], bbox[3]), 
                        (0, 255, 0), 2)
            
            # 라벨 그리기
            cv2.putText(annotated_image, label, 
                       (bbox[0], bbox[1] - 10),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, 
                       (0, 255, 0), 2)

        return tracking_results, annotated_image

def main():
    tracker = YOLOTracker(
        model_path='yolov8n.pt',
        conf_threshold=0.3,
        iou_threshold=0.5
    )
    
    cap = cv2.VideoCapture(0)
    
    # 비디오 저장 설정 (선택사항)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = cv2.VideoWriter('tracking_output.avi', fourcc, 20.0, 
                         (int(cap.get(3)), int(cap.get(4))))
    
    while True:
        ret, frame = cap.read()
        if not ret:
            break
            
        tracking_results, annotated_frame = tracker.track_image(frame)
        
        # 결과 저장 (선택사항)
        out.write(annotated_frame)
        
        # 결과 표시
        cv2.imshow('YOLOv8 Tracking', annotated_frame)
        
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    out.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()