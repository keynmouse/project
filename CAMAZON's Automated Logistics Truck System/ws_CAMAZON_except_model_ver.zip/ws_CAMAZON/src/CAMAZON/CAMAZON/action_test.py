#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped
from rclpy.callback_groups import ReentrantCallbackGroup
import math
import time

class NavigateTestServer(Node):
    def __init__(self):
        super().__init__('navigate_test_server')
        
        # 액션 서버 생성
        self._action_server = ActionServer(
            self,
            NavigateToPose,
            'navigate_to_pose',
            self.execute_callback,
            callback_group=ReentrantCallbackGroup())

        self.get_logger().info('NavigateToPose 테스트 서버가 시작되었습니다.')
        
        # 현재 로봇의 가상 위치 (시뮬레이션용)
        self.current_position = {'x': 0.0, 'y': 0.0}

    def execute_callback(self, goal_handle):
        """
        네비게이션 액션 실행을 시뮬레이션합니다.
        실제 로봇 대신 가상의 움직임을 생성합니다.
        """
        self.get_logger().info('새로운 네비게이션 목표를 받았습니다.')
        
        feedback_msg = NavigateToPose.Feedback()
        result = NavigateToPose.Result()

        # 목표 위치 추출
        target_x = goal_handle.request.pose.pose.position.x
        target_y = goal_handle.request.pose.pose.position.y

        # 시뮬레이션된 이동 구현
        # 현재 위치에서 목표 위치까지 10단계로 나누어 이동
        steps = 10
        dx = (target_x - self.current_position['x']) / steps
        dy = (target_y - self.current_position['y']) / steps

        try:
            for i in range(steps):
                # 목표가 취소되었는지 확인
                if goal_handle.is_cancel_requested:
                    goal_handle.canceled()
                    self.get_logger().info('네비게이션이 취소되었습니다.')
                    return NavigateToPose.Result()

                # 현재 위치 업데이트
                self.current_position['x'] += dx
                self.current_position['y'] += dy

                # 피드백 생성
                feedback_msg.current_pose = PoseStamped()
                feedback_msg.current_pose.header.frame_id = 'map'
                feedback_msg.current_pose.header.stamp = self.get_clock().now().to_msg()
                feedback_msg.current_pose.pose.position.x = self.current_position['x']
                feedback_msg.current_pose.pose.position.y = self.current_position['y']
                feedback_msg.current_pose.pose.orientation.w = 1.0

                # 거리에 따른 진행률 계산
                distance_remaining = math.sqrt(
                    (target_x - self.current_position['x'])**2 +
                    (target_y - self.current_position['y'])**2
                )
                feedback_msg.distance_remaining = distance_remaining
                
                # 피드백 발송
                goal_handle.publish_feedback(feedback_msg)
                self.get_logger().info(
                    f'진행 중: ({self.current_position["x"]:.2f}, '
                    f'{self.current_position["y"]:.2f}), '
                    f'남은 거리: {distance_remaining:.2f}m'
                )

                # 시뮬레이션된 이동 시간
                time.sleep(0.5)

            # 최종 위치 설정
            self.current_position['x'] = target_x
            self.current_position['y'] = target_y

            goal_handle.succeed()
            self.get_logger().info('네비게이션이 성공적으로 완료되었습니다.')
            
            return result

        except Exception as e:
            self.get_logger().error(f'네비게이션 중 오류 발생: {str(e)}')
            goal_handle.abort()
            return result

def main():
    rclpy.init()
    server = NavigateTestServer()
    
    try:
        rclpy.spin(server)
    except KeyboardInterrupt:
        pass
    finally:
        server.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()