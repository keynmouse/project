import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped
import tf2_ros
import tf2_geometry_msgs

class ARobot(Node):

    def __init__(self):
        super().__init__('a_robot_slam')

        # Odometry subscriber to track A robot's position
        self.odom_subscriber = self.create_subscription(
            Odometry,
            '/scan1/odom',
            self.odom_callback,
            10
        )
        
        # TF listener to track A robot's position in TF frame
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.get_logger().info('A Robot SLAM node initialized.')

    def odom_callback(self, msg: Odometry):
        # Extract position from Odometry message
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        self.get_logger().info(f'A robot position from odom: x={x}, y={y}')

    def get_position_in_tf(self):
        try:
            # Get the transform between base_link and odom
            transform = self.tf_buffer.lookup_transform('odom', 'base_link', rclpy.time.Time())
            position = transform.transform.translation
            self.get_logger().info(f'A robot position in tf: x={position.x}, y={position.y}')
            return position.x, position.y
        except tf2_ros.TransformException as ex:
            self.get_logger().error(f'Could not get transform: {ex}')
            return None

def main(args=None):
    rclpy.init(args=args)

    a_robot_node = ARobot()

    rclpy.spin(a_robot_node)

    a_robot_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
