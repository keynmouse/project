import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
import tf2_ros
import tf2_geometry_msgs
import math

class BRobot(Node):

    def __init__(self):
        super().__init__('b_robot_move')
        
        # Action client for NavigateToPose
        self._client = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        # TF listener to track A robot's position in TF frame
        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.get_logger().info('B Robot Move node initialized.')

    def get_position_in_tf(self):
        try:
            # Get the transform between base_link and odom for A robot's position
            transform = self.tf_buffer.lookup_transform('odom', 'base_link', rclpy.time.Time())
            position = transform.transform.translation
            self.get_logger().info(f'Got A robot position: x={position.x}, y={position.y}')
            return position.x, position.y
        except tf2_ros.TransformException as ex:
            self.get_logger().error(f'Could not get transform: {ex}')
            return None

    def move_to_target(self, target_x, target_y):
        # Create a PoseStamped message for the target
        target_pose = PoseStamped()
        target_pose.header.frame_id = 'odom'
        target_pose.header.stamp = self.get_clock().now().to_msg()

        target_pose.pose.position.x = target_x
        target_pose.pose.position.y = target_y
        target_pose.pose.orientation.w = 1.0  # Facing forward

        # Send the goal to the action server
        self._client.wait_for_server()
        self._client.send_goal_async(NavigateToPose.Goal(target_pose))

    def move_to_a_robot(self):
        position = self.get_position_in_tf()
        if position:
            self.move_to_target(position[0], position[1])

def main(args=None):
    rclpy.init(args=args)

    b_robot_node = BRobot()

    # Move B robot to A robot's position
    b_robot_node.move_to_a_robot()

    rclpy.spin(b_robot_node)

    b_robot_node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
