import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import tkinter as tk
from nav_msgs.msg import Odometry
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
from action_msgs.msg import GoalStatus

class TeleopNode(Node):
    def __init__(self):
        super().__init__('teleop_gui_node')
        self.publisher_ = self.create_publisher(Twist, '/scan1/cmd_vel', 10)
        self.subscription = self.create_subscription(Odometry, '/scan1/odom', self.odom_callback, 10)
        self.current_position = (0.0, 0.0, 0.0)
        
    def publish_twist(self, linear_x, angular_z):
        # Twist 메시지 생성
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z

        # 메시지 퍼블리시
        self.publisher_.publish(msg)
        self.get_logger().info(f"Published Twist: Linear X = {linear_x}, Angular Z = {angular_z}")

    def odom_callback(self, msg):
        # Odometry 메시지를 수신할 때 호출됨
        position = msg.pose.pose.position
        orientation = msg.pose.pose.orientation
       
        self.current_position = (position.x, position.y, orientation.z)
    
    def return_current(self):
        return self.current_position

    def send_goal_to_pose(self, x, y, z, w):
        # 액션 클라이언트 생성
        action_client = ActionClient(self, NavigateToPose, '/mine1/navigate_to_pose')
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.stamp.sec = 0
        goal_msg.pose.header.stamp.nanosec = 0
        goal_msg.pose.header.frame_id = 'map'
        
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        goal_msg.pose.pose.position.z = 0.0  # z는 0.0으로 설정

        goal_msg.pose.pose.orientation.x = 0.0
        goal_msg.pose.pose.orientation.y = 0.0
        goal_msg.pose.pose.orientation.z = z
        goal_msg.pose.pose.orientation.w = w

        # 액션 서버가 준비될 때까지 기다림
        self.get_logger().info("Waiting for action server to be available...")
        action_client.wait_for_server()

        self.get_logger().info("Action server is available. Sending goal...")

        # 목표 전송
        action_client.send_goal_async(goal_msg)

    def goal_response_callback(self, future):
        result = future.result()
        if result.status == GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().info('Successfully reached the goal!')
        else:
            self.get_logger().info('Failed to reach the goal.')


class TeleopGUI(tk.Tk):
    def __init__(self, node):
        super().__init__()
        self.node = node

        self.title("Teleoperation GUI")
        self.geometry("400x400")  # 윈도우 크기 확장

        # 버튼: 전방 이동, 후방 이동, 왼쪽 회전, 오른쪽 회전, 정지
        self.label = tk.Label(self, text="Press buttons to control robot")
        self.label.grid(row=0, column=1, pady=10)

        # 방향키 버튼을 십자가 형태로 배치
        self.forward_button = tk.Button(self, text="Forward", command=self.move_forward)
        self.forward_button.grid(row=1, column=1, pady=5)

        self.left_button = tk.Button(self, text="Left", command=self.turn_left)
        self.left_button.grid(row=2, column=0, padx=5)

        self.stop_button = tk.Button(self, text="Stop", command=self.stop)
        self.stop_button.grid(row=2, column=1, padx=5)

        self.right_button = tk.Button(self, text="Right", command=self.turn_right)
        self.right_button.grid(row=2, column=2, padx=5)

        self.backward_button = tk.Button(self, text="Backward", command=self.move_backward)
        self.backward_button.grid(row=3, column=1, pady=5)

        # 새로운 버튼: 목표 지점으로 이동
        self.navigate_button = tk.Button(self, text="Navigate to Goal", command=self.navigate_to_goal)
        self.navigate_button.grid(row=4, column=1, pady=10)

        # 속도 값
        self.linear_speed = 0.5  # 전방/후방 속도
        self.angular_speed = 1.0  # 회전 속도

    def move_forward(self):
        self.node.publish_twist(self.linear_speed, 0.0)

    def move_backward(self):
        self.node.publish_twist(-self.linear_speed, 0.0)

    def turn_left(self):
        self.node.publish_twist(0.0, self.angular_speed)

    def turn_right(self):
        self.node.publish_twist(0.0, -self.angular_speed)
        
    def stop(self):
        self.node.publish_twist(0.0, 0.0)

    def navigate_to_goal(self):
        # 목표 위치와 방향 설정 (예시: 현재 위치로 이동)
        x, y, w = self.node.return_current()
        z = 0.0  # 로봇의 orientation을 위한 z값 설정
        self.node.send_goal_to_pose(x, y, z, w)

    def update_ros2(self):
        # Tkinter 이벤트 루프가 계속 돌아가면서, ROS 2 이벤트를 처리
        rclpy.spin_once(self.node, timeout_sec=0.1)  # 0.1초마다 ROS 2 이벤트 처리


def main():
    rclpy.init()

    # ROS2 노드 생성
    node = TeleopNode()

    # Tkinter GUI 생성
    gui = TeleopGUI(node)

    # GUI 실행
    # Tkinter 이벤트 루프 내에서 ROS 2 이벤트를 처리하기 위해서 update_ros2 호출
    while True:
        gui.update_ros2()
        gui.update()  # Tkinter GUI 업데이트

    rclpy.shutdown()


if __name__ == '__main__':
    main()
