import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from PIL import Image as PILImage, ImageTk
import io
import tkinter as tk
from threading import Thread
from ultralytics import YOLO

class ObjectTracker(Node):
    def __init__(self):
        super().__init__('object_tracker')

        # YOLO 모델 로드
        self.model = YOLO('yolov8n.pt')

        # tkinter window setup
        self.window = tk.Tk()
        self.window.title("Object Tracking Stream")

        # Create a label to display the image
        self.label = tk.Label(self.window)
        self.label.pack()

        # ROS subscription to receive image messages
        self.subscription = self.create_subscription(
            Image,
            '/scan1/camera/image_raw',
            self.image_callback,
            10
        )

        self.get_logger().info("GUI window for object tracking started.")
        
        # Start the ROS node and Tkinter mainloop
        self.window.after(0, self.run_ros_spin)  # Run ROS spin in main thread
        
        # Start the Tkinter GUI main loop (this needs to be in the main thread)
        self.window.mainloop()

    def run_ros_spin(self):
        """ Run ROS spin in a separate thread to keep GUI responsive. """
        threading_thread = Thread(target=self.spin_ros, daemon=True)
        threading_thread.start()

    def spin_ros(self):
        """ ROS spin should run in a background thread. """
        rclpy.spin(self)

    def image_callback(self, msg):
        try:
            # Convert the ROS Image message to a PIL image
            height = msg.height
            width = msg.width
            pil_image = PILImage.frombytes('RGB', (width, height), bytes(msg.data))

            # Run object tracking with YOLO for class 'person' (class ID 0)
            results = self.model.track(source=pil_image, conf=0.3, iou=0.5, classes=[0])

            # 만약 객체가 인식되지 않았다면 원본 이미지를 표시
            if not results:
                result_plotted = pil_image
            else:
                # 객체가 인식되었다면 객체 박스를 추가한 이미지를 표시
                result_plotted = PILImage.fromarray(results[0].plot())

                # 객체 추적 정보 출력
                if hasattr(results[0], 'boxes') and hasattr(results[0].boxes, 'id'):
                    boxes = results[0].boxes
                    for i, id in enumerate(boxes.id):
                        box = boxes.xyxy[i]
                        x1, y1 = box[0], box[1]
                        self.get_logger().info(
                            f"Tracking person (ID {int(id)}) at position ({int(x1)}, {int(y1)})"
                        )

            # PIL 이미지를 Tkinter에서 사용할 수 있는 형식으로 변환
            result_tk = ImageTk.PhotoImage(result_plotted)

            # 이미지를 업데이트 (메인 스레드에서)
            self.label.config(image=result_tk)
            self.label.image = result_tk  # 가비지 컬렉션을 방지하기 위해 참조를 유지

        except Exception as e:
            self.get_logger().error(f'Error in image processing: {str(e)}')

def main(args=None):
    rclpy.init(args=args)
    node = ObjectTracker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
