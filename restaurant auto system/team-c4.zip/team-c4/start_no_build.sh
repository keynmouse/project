#!/bin/bash
# 각 터미널에서 실행할 명령어 정의
# && 연산자로 명령어 순차 실행 보장

CMD2="cd /home/keynmouse/team-c4 && \
	source install/setup.bash && \
	ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py"

CMD3="cd /home/keynmouse/team-c4 && \
	source install/setup.bash && \
	ros2 launch turtlebot3_navigation2 navigation2.launch.py map:=$HOME/map.yaml"

CMD4="cd /home/keynmouse/team-c4 && \
	source install/setup.bash && \
	ros2 run order_manager gui_handler_node"

CMD5="cd /home/keynmouse/team-c4 && \
	source install/setup.bash && \
	ros2 run customer_interface gui_handler_node"


# gnome-terminal로 각 명령어 실행
gnome-terminal -- bash -c "$CMD2; exec bash"
gnome-terminal -- bash -c "$CMD3; exec bash"
gnome-terminal -- bash -c "$CMD4; exec bash"
gnome-terminal -- bash -c "$CMD5; exec bash"
